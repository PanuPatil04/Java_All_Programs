package com.dkte.test;

import java.util.Scanner;

public class LabStaff extends Staff {
   
    private double salary;

    @Override
    public void accept(Scanner sc) {
        super.accept(sc);
        System.out.print("Enter Salary: ");
        salary = sc.nextDouble();
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Salary: " + salary);
    }

    public double getSalary() {
        return salary;
    }
}
