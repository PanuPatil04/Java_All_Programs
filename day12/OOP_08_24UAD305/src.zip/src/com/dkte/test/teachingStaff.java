package com.dkte.test;

import java.util.Scanner;

public class teachingStaff extends Staff {
    private int noofhours;
    private int hours;

    @Override
    public void accept(Scanner sc) {
        super.accept(sc);
        System.out.print("Enter Number of hours: ");
        noofhours = sc.nextInt();
        System.out.print("Enter Working Hours: ");
        hours = sc.nextInt();
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Number of hours: " + noofhours);
        System.out.println("Hours: " + hours);
    }

    public int getHours() {
        return hours;
    }
}
