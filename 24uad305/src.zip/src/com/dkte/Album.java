package com.dkte;

public class Album {
	int album_id;
	String title;
	
	public Album() {
		// TODO Auto-generated constructor stub
	}

	public Album(int album_id, String title) {
		this.album_id = album_id;
		this.title = title;
	}

	public int getAlbum_id() {
		return album_id;
	}

	

	public String getTitle() {
		return title;
	}

	

}
