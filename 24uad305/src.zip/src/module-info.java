/**
 * 
 */
/**
 * 
 */
module db_test {
	requires jdk.jdi;
	requires java.sql;
}