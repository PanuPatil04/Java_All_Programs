package com.dktte;
import java.util.Scanner;
public class Mango extends Fruit {
	Scanner sc=new Scanner(System.in);
	
	public Mango() {
		super();
	}
	//public Mango(String color, double weight, String name, boolean isFresh) {
		//super(color,weight,name,isFresh);
	//}
	
	
	
	public String taste() {
		return "Sweet";
	}

}
