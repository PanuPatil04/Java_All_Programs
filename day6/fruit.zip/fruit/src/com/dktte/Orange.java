package com.dktte;
import java.util.Scanner;
public class Orange extends Fruit {
	Scanner sc=new Scanner(System.in);
	
	public Orange() {
		super();
	}
	//public Orange(String color, double weight, String name, boolean isFresh) {
		//super(color,weight,name,isFresh);
	//}
	
	

	public String taste() {
		return " Sour";
	}

}
